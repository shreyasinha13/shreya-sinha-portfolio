import React from "react";

const HighText = ({ children }) => (
  <span className="text-[#ff2ea6] font-semibold">{children}</span>
);

export default HighText;
